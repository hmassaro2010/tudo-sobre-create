# DrDesten - ShaderCore
A set of common lib files for usage in my shaders
